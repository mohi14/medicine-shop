import React from 'react';

const ServicesNavbar = () => {
    return (
        <div>
            <h1>service</h1>
        </div>
    );
};

export default ServicesNavbar;